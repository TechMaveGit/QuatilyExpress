(function (e) {
    'use strict';
    $('#summernote').summernote();
    $('#summernote1').summernote();
    $('#summernote2').summernote();
    $('#summernote3').summernote();
    $('#summernote4').summernote();
    $('#summernote5').summernote();
    $('#summernote6').summernote();
})();